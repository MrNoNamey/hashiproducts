from flask import Flask, render_template, request, redirect, url_for, session
from datetime import datetime
from dateutil.relativedelta import relativedelta
import hvac


app = Flask(__name__)

app.secret_key = "FLASK_SECRET_KEY"

vault_addr = "http://127.0.0.1:8200"

flask_app_password = None


def get_vault_password(vault_token):
    try:
        vault_client = hvac.Client(url=vault_addr, token=vault_token)
        secret = vault_client.secrets.kv.v2.read_secret_version(
            path="flask-app", mount_point="kv", raise_on_deleted_version=True
        )
        return secret["data"]["data"]["flask_app_password"]
    except hvac.exceptions.InvalidPath as e:
        print(f"Ungültiger Pfad: {e}")
    except hvac.exceptions.Forbidden as e:
        print(f"Zugriff verweigert: {e}")
    except Exception as e:
        print(f"Allgemeiner Fehler: {e}")
    return None


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        vault_token = request.form.get("vault_token")

        if not vault_token:
            return "Vault-Token ist erforderlich.", 400

        try:
            vault_client = hvac.Client(url=vault_addr, token=vault_token)

            if vault_client.is_authenticated():
                try:
                    global flask_app_password
                    flask_app_password = get_vault_password(vault_token)
                    if flask_app_password:
                        session["authenticated"] = True
                        return redirect(url_for("index"))
                    else:
                        return "Passwort konnte nicht aus Vault abgerufen werden.", 500
                except Exception as e:
                    print(f"Fehler beim Abrufen des Passworts aus Vault: {e}")
                    return "Fehler beim Abrufen des Passworts aus Vault.", 500
            else:
                return "Vault-Authentifizierung fehlgeschlagen.", 401
        except Exception as e:
            print(f"Fehler bei der Vault-Authentifizierung: {e}")
            return "Fehler bei der Vault-Authentifizierung.", 500

    return render_template("login.html")


@app.route("/")
def index():
    if "authenticated" not in session:
        return redirect(url_for("login"))

    return render_template("index.html")


@app.route("/alter", methods=["POST"])
def alter():
    if "authenticated" not in session:
        return redirect(url_for("login"))

    try:
        name = request.form.get("name")
        geburtsdatum = request.form.get("geburtsdatum")

        geburtsdatum = datetime.strptime(geburtsdatum, "%Y-%m-%d")
        jetzt = datetime.now()

        if geburtsdatum > jetzt:
            return "Das Geburtsdatum darf nicht in der Zukunft liegen.", 400

        delta = relativedelta(jetzt, geburtsdatum)

        return render_template(
            "index.html",
            name=name,
            alter_in_jahren=delta.years,
            alter_in_monaten=delta.months,
            alter_in_tagen=delta.days,
            rest_stunden=delta.hours,
            rest_minuten=delta.minutes,
            rest_sekunden=delta.seconds,
        )
    except Exception as e:
        print(f"Fehler bei der Berechnung des Alters: {e}")
        return "Fehler bei der Altersberechnung.", 500


@app.route("/logout")
def logout():
    session.pop("authenticated", None)
    return redirect(url_for("login"))


@app.errorhandler(Exception)
def handle_exception(e):
    return f"Ein unerwarteter Fehler ist aufgetreten: {str(e)}", 500


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0")
